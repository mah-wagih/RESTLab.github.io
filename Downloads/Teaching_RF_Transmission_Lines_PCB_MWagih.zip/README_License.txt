Open-Source Transmission Line Teaching Kit

Reference: Please refer to and cite the reference detailing the design procedure https://eprints.gla.ac.uk/323701/

Process Details: JLCPCB, Teflon RF PCBs; PTFE Teflon; H=0.76 mm

© Mahmoud Wagih 2023. This work is openly licensed via CC BY 4.0. see <https://creativecommons.org/licenses/by/4.0/>
